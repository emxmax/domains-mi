<?php

namespace Exsatour\Http\Controllers;

use Mail;
use Illuminate\Http\Request;
use \Exsatour\Usuario;
use SimpleSoftwareIO\QrCode\BaconQrCodeGenerator;

class GeneralController extends Controller
{
  // Mostrar la vista del formulario
  public function index()
  {
    return view('inscripcion', ['dni'=>NULL]);
  }

  //Guardar el registro
  public function store(Request $request)
  {
    $qrcode = new BaconQrCodeGenerator;

    $urlQRCode = url('/active/'.$request->input('dni').'/'.$request->input('nombres').'/'.$request->input('apellidos'));
    $qrcode->format('png')->size(200)->errorCorrection('H')->encoding('UTF-8')->generate( $urlQRCode, 'public/qrcodes/'.$request->input('dni').'.png' );

    Usuario::create([
      'nombres' => $request->input('nombres'),
      'apellidos' => $request->input('apellidos'),
      'dni' => $request->input('dni'),
      'ciudad' => $request->input('ciudad'),
      'celular' => $request->input('celular'),
      'email' => $request->input('email'),
      'estado' => 0
    ]);
    Mail::send('emails.email', $request->all(), function($msj){
      $msj->subject('Correo de Contacto');
      $msj->to('kelvin.ca91@gmail.com');
    });
    return view('inscripcion', ['dni'=> $request->input('dni'), 'email'=> $request->input('email'), 'urlQRCode'=>$urlQRCode]);
  }

  // Activar un usuario a ingresado
  public function activar( $dni, $nombres, $apellidos )
  {
    $usuario = Usuario::where(['dni'=> $dni, 'nombres'=> $nombres, 'apellidos' =>$apellidos ])->first();
    if($usuario){
      if( $usuario->estado == 0 ){
        $usuario = Usuario::where(['id'=> $id])
                  ->update( ['estado' => 1 ] );
        return 'Invitado registrado';
      }else if( $usuario->estado == 1 ){
        return 'Invitado ya ingresó anteriormente';
      }
    }else{
      return 'No existe usuario';
    }
  }

  // Listar los usuarios registrados
  public function lista()
  {
    $lista = Usuario::all();
    return view('lista', ['listUsuarios'=>$lista]);
  }



}
