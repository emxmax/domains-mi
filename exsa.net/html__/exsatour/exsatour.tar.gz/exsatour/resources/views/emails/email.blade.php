<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <table>
      <tr>
        <td>Nombres: </td>
        <td>{{ $nombres }}</td>
      </tr>
      <tr>
        <td>Apellidos: </td>
        <td>{{ $apellidos }}</td>
      </tr>
      <tr>
        <td>Su codigo QR</td>
        <td><img src="http://exsatour.likecom.pe/public/qrcodes/{{$dni}}.png" alt="qr"></td>
      </tr>
    </table>

      </div>
    </div>
  </body>
</html>
