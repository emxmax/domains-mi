<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <table>
      <tr>
        <td>Nombres: </td>
        <td><?php echo e($nombres); ?></td>
      </tr>
      <tr>
        <td>Apellidos: </td>
        <td><?php echo e($apellidos); ?></td>
      </tr>
      <tr>
        <td>Su codigo QR</td>
        <td><img src="http://exsatour.likecom.pe/qrcodes/<?php echo e($dni); ?>.png" alt="qr"></td>
      </tr>
    </table>

      </div>
    </div>
  </body>
</html>
