<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Exsatour</title>
    <link rel="stylesheet" href="<?php echo e(url('/public/stylesheets/bootstrap.min.css')); ?>">
    <!-- <link rel="stylesheet" href="public/stylesheets/master.css"> -->
  </head>
  <body>
    <div class="container-fluid">

      <div class="row justify-content-sm-center" >
        <div class="col-sm-8 col-md-5" style="border: 1px solid #000;">
          <div class="text-center">
            Logo Exsatour
          </div>
          <div class="text-center">
            CHECK - IN EXSA TOUR
            <br>
            PERUMIN 2017
          </div>
          <div class="text-center">
            Completa tus datos y prepárate para la mejor experiencia de Arequipa
          </div>
          <div class="row justify-content-sm-center">
            <div class="col-md-7">
              <?php if( !$dni ): ?>
                <form method="post">
                <div class="form-group">
                  <input type="text" id="nombres" required name="nombres" class="form-control" placeholder="Nombres" />
                </div>
                <div class="form-group">
                  <input type="text" id="apellidos" required name="apellidos" class="form-control" placeholder="Apellidos" />
                </div>
                <div class="form-group">
                  <input type="text" id="dni" name="dni" required class="form-control" placeholder="DNI" />
                </div>
                <div class="form-group">
                  <input type="text" id="ciudad" name="ciudad" required class="form-control" placeholder="Ciudad" />
                </div>
                <div class="form-group">
                  <input type="text" id="celular" name="celular" required class="form-control" placeholder="Celular" />
                </div>
                <div class="form-group">
                  <input type="email" id="email" name="email" required class="form-control" placeholder="Email" />
                </div>
                <div class="form-check text-center">
                 <label class="form-check-label">
                   <input type="checkbox" required name="" class="form-check-input">
                   Acepto los términos y condiciones.
                 </label>
               </div>
               <div class="text-center">
                 <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                 <button type="submit" class="btn btn-primary">Participar</button>
               </div>
              </form>
              <?php else: ?>
                Le enviamos su pass al correo <?php echo e($email); ?>

                <img src="<?php echo e(url('/public/qrcodes/'.$dni.'.png')); ?>" alt="qr">
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>

</html>
