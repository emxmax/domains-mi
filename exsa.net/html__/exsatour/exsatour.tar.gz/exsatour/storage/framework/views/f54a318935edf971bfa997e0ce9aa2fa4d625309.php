<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Exsatour - Lista de usuarios</title>
    <link rel="stylesheet" href="<?php echo e(url('/public/stylesheets/bootstrap.min.css')); ?>">
  </head>
  <body>
    <div class="container">
      <table class="table table-sm table-hover">
        <thead class="thead-inverse">
          <tr>
            <th>#</th>
            <th>Nombres</th>
            <th>Apellidos</th>
            <th>DNI</th>
            <th>Ciudad</th>
            <th>Celular</th>
            <th>Email</th>
            <th>Estado</th>
            <th>Fecha / Hora</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $listUsuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=> $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <th scope="row"><?php echo e($i +1); ?></th>
              <td><?php echo e($row->nombres); ?></td>
              <td><?php echo e($row->apellidos); ?></td>
              <td><?php echo e($row->dni); ?></td>
              <td><?php echo e($row->ciudad); ?></td>
              <td><?php echo e($row->celular); ?></td>
              <td><?php echo e($row->email); ?></td>
              <td><?php echo e(($row->estado==0)? 'Ausente': 'Asistió'); ?></td>
              <td><?php echo e(($row->estado!=0)? $row->updated_at:''); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </body>
</html>
